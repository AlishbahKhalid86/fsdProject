import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginSignup.css';
import user_icon from '../Assets/person.png';
import email_icon from '../Assets/email.png';
import password_icon from '../Assets/password.png';
import axios from 'axios';
const LoginSignup = () => {
  const [formData, setFormData] = React.useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      name: '',
      email: '',
      password: '',
      action: 'Sign Up'
    }
  );
  const [error, setError] = React.useState(null);
  //const router = useRouter();
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const config = {
        withCredentials: true, // Include this line if you need to send cookies
      };
  
      if (formData.action === 'Sign Up') {
        const response = await axios.post('http://localhost:3000/api/users/[userId]', {
          name: formData.name,
          email: formData.email,
          password: formData.password,
        }, config);
        console.log(response.data);
        console.log('User created successfully!');
        setFormData({
          name: '',
          email: '',
          password: '',
          action: 'Login',
        });
      } else {
        const response = await axios.post('http://localhost:3000/api/users/login', {
          email: formData.email,
          password: formData.password,
        }, config);
        if (response.data.success) {
          console.log('Login successful');
          // Handle successful login (e.g., redirect to dashboard)
        } else {
          setError(response.data.message);
        }
      }
    } catch (error) {
      setError('Invalid email or password');
    }
  };
  

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const switchToLogin = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
      action: 'Login'
    });
  };

  const switchToSignUp = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
      action: 'Sign Up'
    });
  };

  return (
    <div className='container'>
      <div className='header'>
        <div className='text'>{formData.action}</div>
        <div className='underline'></div>
      </div>
      <form onSubmit={handleSubmit}>
        <div className='inputs'>
          {formData.action === "Sign Up" ? (
            <div className='input'>
              <img src={user_icon} alt=''/>
              <input type='text' name='name' placeholder='Name' value={formData.name} onChange={handleChange} />
            </div>
          ) : null}
          <div className='input'>
            <img src={email_icon} alt=''/>
            <input type='email' name='email' placeholder='Email' value={formData.email} onChange={handleChange} />
          </div>
          <div className='input'>
            <img src={password_icon} alt=''/>
            <input type='password' name='password' placeholder='Password' value={formData.password} onChange={handleChange} />
          </div>
        </div>
        
        <div className="submit-container">
          <button type="submit" className={formData.action === "Sign Up" ? "submit" : "submit gray"}>Sign Up</button>
          <button type="button" className={formData.action ==="Login" ? "submit" : "submit gray"} onClick={switchToLogin}>Login</button>
        </div>
      </form>
      {formData.action === "Login" ? (
        <div className='switch-container'>
          <div className='text'>Don't have an account?</div>
          <button type="button" className='submit' onClick={switchToSignUp}>Sign Up</button>
        </div>
      ) : null}
    </div>
  );
};

export default LoginSignup;
